# Bobcat Language School — App PWA

App simples de lições de inglês com perfil de aluno, progresso e painel do professor.

Funciona de duas formas:
- **Sem configurar nada**: tudo fica salvo só no navegador do aluno (localStorage). Funciona offline, mas cada aparelho tem seu próprio progresso e ninguém mais enxerga.
- **Com Supabase configurado**: perfil e progresso ficam na nuvem, sincronizados entre aparelhos, e você (professor) consegue ver a turma inteira em `teacher.html`.

Este guia cobre os três passos: **Supabase** (banco de dados) → **GitHub** (código) → **Vercel** (site no ar).

---

## Passo 1 — Supabase (banco de dados)

1. Crie uma conta grátis em [supabase.com](https://supabase.com) e clique em **New project**.
2. Escolha um nome e uma senha de banco (guarde a senha, mas não vai precisar dela aqui).
3. Espere o projeto terminar de subir (~2 minutos).
4. No menu lateral, vá em **SQL Editor** → **New query**, cole todo o conteúdo do arquivo `schema.sql` deste projeto, e clique em **Run**.
   - Isso cria as tabelas `profiles` e `progress`, com as regras de segurança (RLS) já configuradas.
5. Vá em **Authentication → Providers**, encontre **Email** e **ative**. Nessa mesma tela tem a opção **"Confirm email"** — escolha um dos dois caminhos:
   - **Desligado (mais simples):** o aluno cria a conta e já entra na hora, sem precisar checar o e-mail. Bom para turmas pequenas / alunos mais novos.
   - **Ligado (mais seguro):** o aluno recebe um e-mail de confirmação e precisa clicar no link antes de conseguir entrar. Se escolher essa opção, configure também **Authentication → URL Configuration → Site URL** com a URL do seu site (ex. `https://SEU-SITE.vercel.app`), senão o link de confirmação pode não redirecionar direito.
6. Vá em **Project Settings → API**. Copie:
   - **Project URL**
   - **anon public key**
7. Abra o arquivo `config.js` neste projeto e cole os dois valores:

   ```js
   window.SUPABASE_CONFIG = {
     url: 'https://SEU-PROJETO.supabase.co',
     anonKey: 'SUA-CHAVE-ANON-PUBLICA'
   };
   ```

Pronto — o app já vai detectar automaticamente que o Supabase está configurado e passar a exigir login (e-mail + senha) antes de criar o perfil, sincronizando tudo na nuvem (dá pra conferir isso na tela de Perfil do app, que mostra "☁️ Conta na nuvem").

> **Sobre login:** o app usa o e-mail de verdade do aluno + uma senha (mínimo 6 caracteres) no Supabase Auth. Assim, mesmo se o aluno trocar de aparelho, desinstalar o app ou limpar os dados do navegador, ele recupera o perfil e o progresso de qualquer lugar, só entrando de novo com e-mail e senha. Também tem um link **"Esqueci minha senha"** na tela de login, que envia um e-mail de redefinição automaticamente — não precisa mais do professor mexer no painel do Supabase pra isso (mas se preferir, ainda dá pra redefinir manualmente em **Authentication → Users**).

> **Sobre segurança:** a chave `anon public key` é feita para ser exposta no navegador — ela sozinha não dá acesso a nada; quem protege os dados são as regras de RLS no `schema.sql`. Por padrão, cada aluno só consegue **escrever** no próprio perfil/progresso, mas **qualquer** aluno logado consegue **ler** todos os perfis — é isso que permite o painel do professor funcionar sem precisar de um login separado de professor. Para uma turma pequena isso costuma ser aceitável; se quiser bloquear a leitura só para um login de professor de verdade, é só pedir que eu ajusto o schema.

> **Sem Supabase configurado:** o app funciona do mesmo jeito de antes — sem tela de login, perfil salvo só no navegador (localStorage). É só para quando você quiser sincronizar entre aparelhos e ter o painel do professor que vale a pena configurar o Supabase.

---

## Passo 2 — GitHub (guardar o código)

Se ainda não tem o Git configurado, instale em [git-scm.com](https://git-scm.com).

Dentro da pasta do projeto:

```bash
git init
git add .
git commit -m "Bobcat app: perfil, lições e painel do professor"
```

Crie um repositório novo (vazio, sem README) em [github.com/new](https://github.com/new), depois:

```bash
git remote add origin https://github.com/SEU-USUARIO/bobcat-app.git
git branch -M main
git push -u origin main
```

---

## Passo 3 — Vercel (colocar no ar)

1. Crie uma conta grátis em [vercel.com](https://vercel.com) (dá pra entrar direto com GitHub).
2. Clique em **Add New → Project**.
3. Selecione o repositório `bobcat-app` que você acabou de subir.
4. Em **Framework Preset**, deixe como **Other** (é um site estático, não precisa de build).
5. Clique em **Deploy**.

Em menos de um minuto você recebe um link tipo `https://bobcat-app.vercel.app`. É só esse link que os alunos vão abrir — em um celular, o navegador vai oferecer **"Adicionar à tela inicial"** automaticamente (é o PWA sendo instalado).

Toda vez que você der `git push`, a Vercel republica sozinha.

---

## Passo 4 — IA para praticar conversação (opcional, e gratuito)

O app tem uma tela **"🤖 Praticar com IA"** onde o aluno **cria suas próprias personalidades de IA** — escolhe um avatar, um nome, um **gênero (feminino ou masculino)** e descreve a personalidade do jeito que quiser (ex: "uma astronauta aventureira que adora contar histórias sobre o espaço") — e cada personalidade vira uma conversa exclusiva, com histórico salvo separado. O gênero escolhido define os pronomes que a IA usa para si mesma em inglês (she/her ou he/him) e, quando o navegador do aluno tiver vozes em inglês disponíveis, também influencia a voz usada na leitura em voz alta. O aluno pode criar quantas personalidades quiser (ficam numa lista, tipo contatos) e voltar a conversar com qualquer uma delas depois. A IA ajusta o vocabulário ao nível do aluno e corrige erros com gentileza, mantendo o "jeito de ser" descrito, mas sempre dentro das regras de segurança do app (isso vale mesmo que o aluno tente descrever uma personalidade que peça pra "ignorar as regras" — o servidor sempre prioriza a segurança). Isso usa o **Gemini API do Google (Google AI Studio)**, que tem uma cota gratuita generosa (bem mais do que uma escola pequena usaria) — não precisa cartão de crédito.

> As personalidades e as conversas ficam salvas só no navegador/aparelho do aluno (localStorage) — não sincronizam entre aparelhos nem aparecem para o professor, mesmo com Supabase configurado.

1. Acesse [aistudio.google.com](https://aistudio.google.com), entre com uma conta Google e clique em **Get API key → Create API key**.
2. Copie a chave gerada (começa com `AIza...`).
3. No painel da Vercel, abra o projeto do app → **Settings → Environment Variables**.
4. Adicione uma variável:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** cole a chave que você copiou
   - Marque para os ambientes **Production** (e Preview, se usar).
5. Clique em **Save**, depois vá em **Deployments** e clique em **Redeploy** no último deploy (para a variável nova entrar em vigor).

Pronto — a chave fica só no servidor da Vercel, nunca aparece no navegador do aluno. Se você não configurar essa variável, a tela de chat continua no app mas mostra um aviso avisando que a IA não está configurada, sem quebrar o resto do app.

> **Sobre custo:** o Gemini 2.5 Flash-Lite (modelo usado por padrão, veja `api/chat.js`) tem uma cota diária gratuita alta o bastante para o uso normal de uma turma. Se um dia a escola crescer muito e passar da cota grátis, dá pra ativar faturamento no Google AI Studio (paga só pelo excedente) — mas isso é opcional e você decide se/quando fazer isso.

---

## Lembretes por notificação (Web Push)

Na tela **Praticar com IA** o aluno pode ativar **Lembretes de prática**. Isso usa Web Push + Service Worker: mesmo com o app fechado, o celular pode receber um toque do tipo “Hora de praticar inglês!”.

### O que já funciona no app
- Botão **Ativar / Desativar** lembretes
- Pedido de permissão de notificação
- Inscrição Push (subscription) salva no aparelho e, com Supabase, também na tabela `push_subscriptions`
- Service Worker exibe a notificação e, ao tocar, abre a tela de Praticar com IA
- **Notificação de teste** (local, sem servidor)
- Com Shift + clique no teste: envia push de verdade via `/api/push-send` (precisa das chaves VAPID na Vercel)

### Configuração na Vercel (obrigatória para push real)

1. As chaves VAPID do projeto já estão pareadas:
   - **Pública** → em `config.js` (`APP_CONFIG.vapidPublicKey`)
   - **Privada** → só na Vercel (nunca no código)

2. No painel da Vercel → **Settings → Environment Variables**, adicione:

| Name | Value |
|------|--------|
| `VAPID_PUBLIC_KEY` | a mesma pública de `config.js` |
| `VAPID_PRIVATE_KEY` | `A4LhDtBYLHCFdB1TC8znW78xCxwfappz6Wtp4-L_rxA` |
| `VAPID_SUBJECT` | `mailto:seu-email@escola.com` |
| `SUPABASE_URL` | (opcional) URL do projeto Supabase — para enviar à turma inteira |
| `SUPABASE_SERVICE_ROLE_KEY` | (opcional) service role do Supabase — só no servidor |
| `GEMINI_API_KEY` | (opcional, mesma chave do `api/chat.js`) com Supabase + essa chave, o lembrete vira personalizado com base na última conversa (veja abaixo) |
| `PUSH_SEND_SECRET` | (opcional) senha que o cron/painel deve mandar no header `x-push-secret` |

3. Rode de novo o `schema.sql` no Supabase (a tabela `push_subscriptions` é criada de forma segura).

4. **Redeploy** o projeto na Vercel (para instalar a dependência `web-push` do `package.json`).

> Se quiser gerar **outro** par de chaves: `npx web-push generate-vapid-keys` — atualize a pública em `config.js` e a pública+privada nas env vars.

### Enviar lembrete para a turma (manual ou cron)

```bash
curl -X POST https://SEU-SITE.vercel.app/api/push-send \
  -H "Content-Type: application/json" \
  -H "x-push-secret: SUA_SENHA_SE_CONFIGUROU" \
  -d '{"title":"Bobcat 🐱","body":"Hora de praticar inglês com a IA!","url":"./index.html?screen=ai-chat"}'
```

Isso exige `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY` configurados. Sem isso, o endpoint ainda aceita uma `subscription` avulsa no body (como o botão de teste com Shift faz).

Para agendar (ex.: 8h e 18h), use **Vercel Cron** apontando para essa rota, ou um serviço externo de cron.

### Limitações
- **iPhone (Safari/PWA):** Web Push em PWA no iOS exige iOS 16.4+ e o app instalado na tela inicial; o suporte ainda é mais limitado que no Android.
- **Android + Chrome:** funciona bem com o app instalado ou aberto no navegador.
- A notificação em si é um lembrete genérico; ao abrir o chat, a mensagem proativa da personalidade (já implementada) continua gerando o “bom dia / como você está?” no tom da IA.

### Lembrete personalizado com a última conversa

Se **Supabase** e **`GEMINI_API_KEY`** estiverem configurados na Vercel, o `/api/push-send` personaliza automaticamente o título/corpo do lembrete de cada aluno com base no final da última conversa dele com a IA — algo como *"Mia 🐱 — Ready to talk about that trip to Rio?"* em vez do texto genérico.

Como funciona:
- A cada resposta da IA no chat, o app grava um resumo (últimas ~8 mensagens) na tabela `ai_chat_last_conversation` do Supabase — só isso, não o histórico completo (que continua só no aparelho do aluno).
- Ao enviar o lembrete, o servidor busca esse resumo por aluno e pede pro Gemini gerar um `title`/`body` curtos referenciando o assunto.
- Sem conversa registrada, sem `GEMINI_API_KEY`, ou se o Gemini falhar nesse aluno em particular, cai automaticamente no `title`/`body` genérico enviado no `curl`/cron.
- Para desligar a personalização em um envio específico (ex.: um aviso igual pra turma toda), mande `"personalize": false` no body do POST.
- Por segurança de custo, um mesmo envio gera no máximo 60 lembretes personalizados (turmas maiores que isso recebem o texto genérico para o excedente).
- Exige rodar de novo o `schema.sql` no Supabase (cria a tabela `ai_chat_last_conversation`).

---

## Estrutura do projeto

```
index.html           → tela de perfil + lista de lições (o app em si)
app.js                → lógica de navegação e telas
db-client.js          → decide entre Supabase (nuvem) e localStorage (offline)
config.js             → suas chaves do Supabase + VAPID pública (edite aqui)
api/chat.js            → função serverless (Vercel) que fala com a IA — a GEMINI_API_KEY fica aqui, como variável de ambiente, nunca neste arquivo
api/explain-error.js   → mesma chave/modelo do chat; gera as explicações da "Trilha de Erro" (tela de fim de lição, quando o aluno não passa)
api/push-send.js       → envia notificações Web Push (VAPID + opcionalmente Supabase)
style.css             → visual do app
manifest.json         → deixa o app instalável
sw.js                 → cache offline + handlers de push/notificationclick
schema.sql            → script para criar as tabelas no Supabase
teacher.html         → painel do professor (só funciona com Supabase configurado)
package.json          → dependência web-push (Vercel instala no deploy)
icons/               → ícones do app
lessons/
  verb-to-be.html    → lição interativa "Verb To Be"
```

## Adicionando novas lições

Tem dois jeitos de adicionar lição: **pelo painel do professor** (mais simples, não mexe em código) ou **direto nos arquivos do projeto** (o jeito "clássico", exige um novo `git push`).

### Pelo painel do professor (upload de HTML, sem mexer em código)

Só funciona com o Supabase configurado (a lição fica guardada no banco, já que o app é um site estático e não tem como criar arquivo novo sozinho).

1. Monte o arquivo `.html` da lição do jeito de sempre: duplique `lessons/verb-to-be.html` (ou `lessons/saudacoes-apresentacoes.html`, que já tem áudio embutido) e troque o conteúdo, mantendo:
   - a linha `const LESSON_ID = '...'` com um id novo e único (o mesmo que você vai usar no campo "ID" do painel);
   - as três tags `<script src="../config.js">`, `<script src="../db-client.js">` e o `<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2">` no `<head>`;
   - a função `finishLesson()` (ajuste a contagem de `total` para o número de questões da nova lição).
2. Abra `teacher.html` → aba **"➕ Adicionar Lição"**.
3. Escolha se ela entra em **"Lições"** (agrupada pelo nível, com bloqueio sequencial normal — o aluno precisa concluir a anterior do catálogo pra desbloquear) ou **"Extra"** (libera direto, sem bloqueio, como o Manual de Português).
4. Preencha nível (ex. `B2`), ícone, nome, descrição e número de questões, confira o ID gerado automaticamente a partir do nome (pode editar) e selecione o arquivo `.html` que você montou no passo 1.
5. Clique em **"Adicionar lição"** — ela já aparece no app dos alunos na hora, sem precisar publicar nada de novo no GitHub/Vercel.

A lição é aberta pelo endereço `lessons/custom.html?id=SEU-ID`, uma página "carregadora" que busca o HTML salvo no banco e o exibe — por isso os caminhos relativos (`../config.js`, `../index.html` etc.) dentro dela continuam funcionando normalmente. Pra excluir ou conferir as lições já enviadas, use a lista logo abaixo do formulário nessa mesma aba (excluir a lição do catálogo não apaga o progresso que os alunos já tiverem salvo nela).

> É preciso rodar a nova tabela do `schema.sql` (`custom_lessons`, perto do final do arquivo) no SQL Editor do Supabase se você já tinha o banco configurado antes dessa atualização.

### Direto nos arquivos do projeto (o jeito "clássico")

1. Duplique `lessons/verb-to-be.html` (ou `lessons/saudacoes-apresentacoes.html`, que já tem áudio embutido), troque o conteúdo pela nova lição, mas mantenha:
   - a linha `const LESSON_ID = '...'` com um id novo e único;
   - as três tags `<script src="../config.js">`, `<script src="../db-client.js">` e o `<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2">` no `<head>`;
   - a função `finishLesson()` (ajuste a contagem de `total` para o número de questões da nova lição).
2. Em `app.js`, adicione a lição no array `LESSONS` no topo do arquivo.
3. Em `sw.js`, adicione o novo arquivo à lista `APP_SHELL` para funcionar offline, e suba o número em `CACHE_NAME` (ex.: `bobcat-app-v3` → `v4`) para forçar o navegador dos alunos a buscar a versão nova.

### Transformando um PDF de lição em lição interativa

Fluxo recomendado para pegar uma apostila em PDF (como a de "Saudações e Apresentações") e virar uma lição do app:

1. Extraia do PDF: objetivo da aula, vocabulário novo, diálogo modelo, exercícios (e o gabarito).
2. Duplique um arquivo `.html` de lição existente e reescreva o conteúdo, reaproveitando os componentes já prontos: `.fill-grid` (completar lacunas), `.mc-item`/`.mc-options` (múltipla escolha), `.dialog-box` (diálogo).
3. Adapte a função `checkParts()`/`finishLesson()` com as respostas certas de cada exercício novo.
4. Registre a lição em `app.js` e `sw.js` como no passo acima.

### Áudio (pronúncia) sem precisar hospedar arquivos de som

A lição `saudacoes-apresentacoes.html` já usa a **Web Speech API** do navegador (`speechSynthesis`), que faz o próprio navegador "falar" o texto em inglês — não precisa gravar, subir nem hospedar nenhum arquivo `.mp3`. Função pronta (`speak(btn, texto)`) e um botão `🔊 ouvir` já ficam ao lado de cada palavra/frase do vocabulário e do diálogo. Para reaproveitar em outra lição, basta chamar `speak(this, 'texto em inglês')` no `onclick` de um botão com a classe `audio-btn`.
   - Vantagem: funciona offline, sem custo, sem hospedagem.
   - Limitação: a voz depende do navegador/aparelho do aluno (qualidade varia, mas é totalmente aceitável para prática de pronúncia).

### Vídeo

Para vídeo real (ex. um vídeo do YouTube sobre o tema), incorpore um `<iframe>` no corpo da lição, por exemplo:

```html
<div class="video-box">
  <iframe width="100%" height="315"
    src="https://www.youtube.com/embed/SEU_VIDEO_ID"
    title="Vídeo da lição" frameborder="0" allowfullscreen></iframe>
</div>
```

Troque `SEU_VIDEO_ID` pelo ID do vídeo escolhido (a parte depois de `watch?v=` na URL do YouTube). A lição `saudacoes-apresentacoes.html` já tem um bloco `.video-box` reservado para isso — é só trocar o texto de aviso pelo `<iframe>`.


## Painel do professor

Depois de configurar o Supabase, abra `https://SEU-SITE.vercel.app/teacher.html` — mostra todos os alunos que já criaram perfil, pontuação por lição e data da última tentativa. Dá pra favoritar esse link separado do app dos alunos.

## Canal de mensagens (aluno ↔ professor)

Cada aluno tem, no próprio perfil (aba "Perfil" → "💬 Fale com o professor"), um campo para mandar mensagens/dúvidas. Elas chegam para o professor na aba "💬 Mensagens" de `teacher.html`, organizadas por aluno (como uma caixa de conversas), e o professor pode responder por lá — a resposta aparece de volta no app do aluno.

Esse recurso **só funciona com o Supabase configurado** (não existe versão local/offline, já que a mensagem precisa "viajar" de um aparelho para o outro). Se você já tinha o Supabase configurado antes dessa atualização, é preciso rodar a nova parte do `schema.sql` (a tabela `messages` e as políticas dela, logo abaixo da tabela `progress`) no SQL Editor do Supabase — o restante do arquivo pode ser executado de novo sem problema, os `create table if not exists` e `drop policy if exists` são seguros para rodar mais de uma vez.

### Enviando arquivos pelo chat (PDF, Word, texto, planilha, imagem...)

Ao lado da caixa de mensagem, tanto no app do aluno quanto no painel do professor, tem um botão 📎 para anexar um arquivo — junto com o texto, ou sozinho, sem escrever nada. Tipos aceitos: PDF, Word (`.doc`/`.docx`), OpenDocument (`.odt`), RTF, texto (`.txt`), planilha (`.xls`/`.xlsx`/`.csv`), apresentação (`.ppt`/`.pptx`) e imagens (`.jpg`/`.png`). Tamanho máximo: 10MB por arquivo. O arquivo aparece na conversa como um cartão clicável que abre/baixa o anexo.

Os arquivos ficam guardados no **Supabase Storage**, num bucket chamado `mensagens-arquivos` (criado automaticamente ao rodar o `schema.sql` — não precisa criar nada manualmente no painel do Supabase). Se você já tinha o Supabase configurado antes dessa atualização, rode o `schema.sql` de novo no SQL Editor: ele adiciona as colunas novas na tabela `messages` (`file_url`, `file_name`, `file_type`, `file_size`) e cria o bucket + políticas de Storage, tudo de forma segura para rodar mais de uma vez.

> **Sobre segurança dos arquivos:** o bucket é público (mesmo trade-off já assumido no resto do projeto) — quem tiver o link direto do arquivo consegue abrir, mas ninguém consegue enviar ou listar arquivos sem estar autenticado (aluno logado ou o painel do professor). Para uma turma pequena costuma ser um risco aceitável.

## Senha para zerar progresso (uma por aluno)

O botão "Zerar progresso das lições" (no perfil do aluno) agora pede uma senha antes de apagar qualquer coisa. Essa senha é **definida pelo professor, individualmente para cada aluno**, na aba "🔑 Senhas" de `teacher.html` — basta digitar a senha desejada no campo do aluno e clicar em Salvar (deixar em branco remove a senha, e sem senha o aluno não consegue zerar sozinho).

- Com Supabase configurado: cada aluno usa a própria senha, cadastrada pelo professor.
- Sem Supabase (app rodando só localmente): não existe painel do professor, então o app cai para a senha única em `config.js` → `window.APP_CONFIG.resetProgressPassword`, que serve como alternativa.
- Assim como as outras senhas deste projeto (é um app 100% front-end), essa não é um segredo criptográfico à prova de tudo — quem souber mexer no navegador consegue contornar. Ela serve para evitar zeragem sem querer ou sem autorização, não como proteção contra alguém tecnicamente insistente.

Também é preciso rodar a nova tabela do `schema.sql` (`student_reset_passwords`, perto do final do arquivo) no SQL Editor do Supabase se você já tinha o banco configurado antes dessa atualização.

---

## Design interativo das lições (estilo Genially)

A **Lição 2** usa o novo visual interativo (HUD com XP, cartões viráveis, jogos de memória/quiz, áudio TTS, confetti).

### Arquivos compartilhados

- `lessons/lesson-kit.js` — HUD/XP, `speak()`, reveal on scroll, flip cards, e **ponte de progresso** com `db-client.js` (`handleLessonFinish`).
- Inclua nos HTML de lição (nessa ordem):

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="../config.js"></script>
<script src="../db-client.js"></script>
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.4/dist/confetti.browser.min.js"></script>
<script src="lesson-kit.js"></script>
```

```js
BobcatLesson.init({ lessonId: 'licao-2-perguntas-artigos', totalQuestions: 20 });
// ao finalizar:
await BobcatLesson.finishLesson(correct, total, 'correct'); // ou 'filled'
```

### Progresso real

- Nota mínima continua **85%** (`PASSING_PCT` em `db-client.js`).
- Na Lição 2 interativa a pontuação é composta: drag-drop (8) + quiz (6) + memória (6) = 20.
- Fotos: Pexels & domínio público · Design interativo inspirado em Genially.

Para migrar outras lições ao mesmo visual: reutilize o CSS/estrutura da Lição 2 e o `lesson-kit.js`; mantenha o mesmo `LESSON_ID` do catálogo em `app.js`.
